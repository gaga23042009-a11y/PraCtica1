import io
from datetime import datetime

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

FACE = "😞😐🙂😊🤩"
DOW = ("понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье")


def _pack(rows):
    return [dict(r) for r in rows] if rows else []


def _day(s):
    return datetime.strptime(s, "%Y-%m-%d") if isinstance(s, str) else s


def _avg(nums):
    return sum(nums) / len(nums) if nums else 0


def _link(a, b):
    if len(a) < 2:
        return None
    ma, mb = _avg(a), _avg(b)
    up = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    da = sum((x - ma) ** 2 for x in a) ** 0.5
    db = sum((y - mb) ** 2 for y in b) ** 0.5
    return None if da == 0 or db == 0 else up / (da * db)


def summary(rows, label):
    items = _pack(rows)
    if not items:
        return f"За {label} записей нет. Добавь данные через /add."

    moods = [x["mood"] for x in items]
    works = [x["work_hours"] for x in items]
    sleeps = [x["sleep_hours"] for x in items]
    top = max(items, key=lambda x: x["mood"])
    low = min(items, key=lambda x: x["mood"])
    e = FACE[round(_avg(moods)) - 1]

    return (
        f"Сводка за {label}:\n\n"
        f"Среднее настроение: {_avg(moods):.1f} {e}\n"
        f"Средние часы работы/учёбы: {_avg(works):.1f}\n"
        f"Средние часы сна: {_avg(sleeps):.1f}\n\n"
        f"Лучший день: {_day(top['date']).strftime('%d.%m.%Y')} — "
        f"{top['mood']} {FACE[top['mood'] - 1]}\n"
        f"Худший день: {_day(low['date']).strftime('%d.%m.%Y')} — "
        f"{low['mood']} {FACE[low['mood'] - 1]}"
    )


def insights(rows):
    items = _pack(rows)
    if len(items) < 3:
        return "Недостаточно данных для инсайтов. Нужно хотя бы 3 записи."

    by_dow = {}
    for x in items:
        w = _day(x["date"]).weekday()
        by_dow.setdefault(w, []).append(x["mood"])
    avg_dow = {w: _avg(v) for w, v in by_dow.items()}
    good = max(avg_dow, key=avg_dow.get)
    bad = min(avg_dow, key=avg_dow.get)

    light = [x["mood"] for x in items if x["work_hours"] <= 2]
    heavy = [x["mood"] for x in items if x["work_hours"] > 4]
    if not light or not heavy:
        about_work = "Недостаточно данных, чтобы оценить влияние учёбы/работы на настроение."
    elif _avg(heavy) < _avg(light) - 0.3:
        about_work = "При >4 ч работы/учёбы настроение в среднем ниже, чем при ≤2 ч."
    elif _avg(heavy) > _avg(light) + 0.3:
        about_work = "При большей нагрузке настроение в среднем не ниже."
    else:
        about_work = "Часы работы/учёбы заметно не влияют на настроение."

    r = _link([x["sleep_hours"] for x in items], [x["work_hours"] for x in items])
    if r is None:
        about_sleep = "Недостаточно данных о сне и продуктивности."
    elif r > 0.3:
        about_sleep = "В дни с большим сном часто больше часов работы."
    elif r < -0.3:
        about_sleep = "При большем сне в среднем меньше часов работы."
    else:
        about_sleep = "Прямой связи между сном и продуктивностью не видно."

    return (
        "Мои инсайты:\n\n"
        f"Дни недели:\n"
        f"Выше в {DOW[good]} ({avg_dow[good]:.1f}), ниже в {DOW[bad]} ({avg_dow[bad]:.1f}).\n\n"
        f"Учёба/работа и настроение:\n{about_work}\n\n"
        f"Сон и продуктивность:\n{about_sleep}"
    )


def chart(rows):
    items = sorted(_pack(rows), key=lambda x: x["date"])[-7:]
    if not items:
        return None

    xs = [_day(x["date"]).strftime("%d.%m") for x in items]
    mood = [x["mood"] for x in items]
    sleep = [x["sleep_hours"] for x in items]
    work = [x["work_hours"] for x in items]

    fig, left = plt.subplots(figsize=(8, 4))
    left.plot(xs, mood, "o-", label="Настроение")
    left.set_ylim(1, 5)
    right = left.twinx()
    right.plot(xs, sleep, "s-", label="Сон")
    right.plot(xs, work, "^-", label="Работа/учёба")
    h1, l1 = left.get_legend_handles_labels()
    h2, l2 = right.get_legend_handles_labels()
    left.legend(h1 + h2, l1 + l2)
    left.set_title("Последние 7 дней")
    fig.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    return buf


def history_line(row):
    d = _day(row["date"]).strftime("%d.%m.%Y")
    m = int(row["mood"])
    line = f"{d} | настроение {m} {FACE[m - 1]}\nработа/учёба: {row['work_hours']} ч, сон: {row['sleep_hours']} ч"
    if row["comment"]:
        line += f"\nкомментарий: {row['comment']}"
    return line
