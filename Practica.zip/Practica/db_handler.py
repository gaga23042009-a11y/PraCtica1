import sqlite3
from datetime import date, timedelta
from pathlib import Path

BASE = Path(__file__).parent
DB_FILE = BASE / "tracker.db"


def _open():
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    return con


def setup():
    sql = (BASE / "schema.sql").read_text(encoding="utf-8")
    with _open() as con:
        con.executescript(sql)
        con.commit()


def today_exists(uid):
    d = date.today().isoformat()
    with _open() as con:
        return con.execute(
            "SELECT 1 FROM daily_records WHERE user_id=? AND date=?",
            (uid, d),
        ).fetchone() is not None


def save_day(uid, mood, work, sleep, note=None):
    d = date.today().isoformat()
    with _open() as con:
        con.execute(
            """INSERT INTO daily_records
               (user_id, date, mood, work_hours, sleep_hours, comment)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (uid, d, mood, work, sleep, note),
        )
        con.commit()


def days_list(uid, span):
    start = (date.today() - timedelta(days=span - 1)).isoformat()
    with _open() as con:
        return con.execute(
            """SELECT date, mood, work_hours, sleep_hours, comment
               FROM daily_records
               WHERE user_id=? AND date>=?
               ORDER BY date""",
            (uid, start),
        ).fetchall()


def recent(uid, n=7):
    with _open() as con:
        return con.execute(
            """SELECT date, mood, work_hours, sleep_hours, comment
               FROM daily_records WHERE user_id=?
               ORDER BY date DESC LIMIT ?""",
            (uid, n),
        ).fetchall()


def wipe(uid):
    with _open() as con:
        cur = con.execute("DELETE FROM daily_records WHERE user_id=?", (uid,))
        con.commit()
        return cur.rowcount


def total(uid):
    with _open() as con:
        return con.execute(
            "SELECT COUNT(*) c FROM daily_records WHERE user_id=?", (uid,)
        ).fetchone()["c"]


def get_alarm(uid):
    with _open() as con:
        r = con.execute(
            "SELECT reminder_time FROM user_settings WHERE user_id=?", (uid,)
        ).fetchone()
    return r["reminder_time"] if r else None


def set_alarm(uid, hhmm):
    with _open() as con:
        con.execute(
            """INSERT INTO user_settings (user_id, reminder_time) VALUES (?,?)
               ON CONFLICT(user_id) DO UPDATE SET reminder_time=excluded.reminder_time""",
            (uid, hhmm),
        )
        con.commit()


def all_alarms():
    with _open() as con:
        return [
            (r["user_id"], r["reminder_time"])
            for r in con.execute(
                "SELECT user_id, reminder_time FROM user_settings WHERE reminder_time IS NOT NULL"
            )
        ]


if __name__ == "__main__":
    setup()
    print("Готово:", DB_FILE)
