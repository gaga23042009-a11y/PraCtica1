import re
import threading
from datetime import datetime, timedelta

import telebot
from telebot import types

import analyzer
import db_handler as db

TOKEN = "8899082887:AAGcTbYamrdqhPV92pudCirq2J6xx7yq59g"
if not TOKEN:
    raise RuntimeError("Задайте переменную окружения BOT_TOKEN")

tg = telebot.TeleBot(TOKEN)
sess = {}          # uid -> (шаг, черновик)
alarms = {}        # uid -> Timer

BTN = {
    "add": "➕ Записать день",
    "stats": "📊 Статистика",
    "hist": "📋 История",
    "set": "⚙️ Настройки",
}

TEXT = {
    "hi": (
        "Трекер настроения и продуктивности.\n\n"
        "Записывай настроение, часы работы/учёбы и сон — "
        "получишь статистику и инсайты.\n\n"
        "Начни с «Записать день» или /add."
    ),
    "help": (
        "/start — приветствие\n/add — запись за сегодня\n/stats — статистика\n"
        "/history — записи\n/settings — напоминание\n/clear — удалить данные\n/help — справка"
    ),
}


def menu():
    k = types.ReplyKeyboardMarkup(resize_keyboard=True)
    k.row(BTN["add"], BTN["stats"])
    k.row(BTN["hist"], BTN["set"])
    return k


def btn_grid(pairs, width=3):
    k = types.InlineKeyboardMarkup(row_width=width)
    row = []
    for label, code in pairs:
        row.append(types.InlineKeyboardButton(label, callback_data=code))
        if len(row) == width:
            k.row(*row)
            row = []
    if row:
        k.row(*row)
    return k


def mood_btns():
    return btn_grid(
        [("1 😞", "m1"), ("2 😐", "m2"), ("3 🙂", "m3"), ("4 😊", "m4"), ("5 🤩", "m5")],
        width=5,
    )


def work_btns():
    return btn_grid(
        [("0.5 ч", "w0.5"), ("1 ч", "w1"), ("2 ч", "w2"), ("4 ч", "w4"), ("Другое...", "w+")],
        width=3,
    )


def sleep_btns():
    return btn_grid(
        [("6 ч", "s6"), ("7 ч", "s7"), ("8 ч", "s8"), ("9 ч", "s9"), ("Другое...", "s+")],
        width=4,
    )


def say(cid, text, kb=None):
    tg.send_message(cid, text, reply_markup=kb or menu())


def drop(uid):
    sess.pop(uid, None)


def step(uid):
    return sess.get(uid, (None, {}))[0]


def buf(uid):
    return sess.get(uid, (None, {}))[1]


def go(uid, name, data=None):
    sess[uid] = (name, data if data is not None else buf(uid))


def num_ok(t):
    try:
        v = float(t.strip().replace(",", "."))
    except ValueError:
        return None
    return v if 0 <= v <= 24 else None


def time_ok(t):
    return bool(re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", t.strip()))


def wait_secs(hhmm):
    h, m = map(int, hhmm.split(":"))
    now = datetime.now()
    at = now.replace(hour=h, minute=m, second=0, microsecond=0)
    if at <= now:
        at += timedelta(days=1)
    return (at - now).total_seconds()


def arm(uid, hhmm):
    old = alarms.pop(uid, None)
    if old:
        old.cancel()

    def ring():
        try:
            say(uid, "Напоминание: запиши день — «Записать день» или /add")
        except Exception:
            pass
        arm(uid, hhmm)

    t = threading.Timer(wait_secs(hhmm), ring)
    t.daemon = True
    t.start()
    alarms[uid] = t


def begin_add(cid, uid):
    if db.today_exists(uid):
        say(cid, "Запись за сегодня уже есть.")
        return
    go(uid, "mood", {})
    say(cid, "Оцени настроение от 1 до 5 (1 — ужасно, 5 — отлично).", mood_btns())


def finish(cid, uid, note=None):
    d = buf(uid)
    try:
        db.save_day(uid, d["mood"], d["work"], d["sleep"], note)
    except Exception:
        say(cid, "Запись за сегодня уже существует.")
        drop(uid)
        return
    face = analyzer.FACE[d["mood"] - 1]
    msg = (
        f"Сохранено.\nНастроение: {d['mood']} {face}\n"
        f"Работа/учёба: {d['work']} ч\nСон: {d['sleep']} ч"
    )
    if note:
        msg += f"\nКомментарий: {note}"
    say(cid, msg)
    drop(uid)


@tg.message_handler(commands=["start"])
def h_start(m):
    say(m.chat.id, TEXT["hi"])


@tg.message_handler(commands=["help"])
def h_help(m):
    say(m.chat.id, TEXT["help"])


@tg.message_handler(commands=["add"])
def h_add(m):
    begin_add(m.chat.id, m.from_user.id)


@tg.message_handler(commands=["stats"])
def h_stats(m):
    k = types.InlineKeyboardMarkup()
    k.row(types.InlineKeyboardButton("📅 За неделю", callback_data="st7"))
    k.row(types.InlineKeyboardButton("🗓 За месяц", callback_data="st30"))
    k.row(types.InlineKeyboardButton("🔍 Мои инсайты", callback_data="stins"))
    k.row(types.InlineKeyboardButton("📉 График", callback_data="stpic"))
    say(m.chat.id, "Что хочешь узнать?", k)


@tg.message_handler(commands=["history"])
def h_hist(m):
    rows = db.recent(m.from_user.id)
    if not rows:
        say(m.chat.id, "История пуста. Добавь запись через /add.")
        return
    body = "\n\n".join(analyzer.history_line(r) for r in rows)
    say(m.chat.id, "История:\n\n" + body)


@tg.message_handler(commands=["settings"])
def h_set(m):
    cur = db.get_alarm(m.from_user.id)
    extra = f"\nСейчас: {cur}" if cur else ""
    go(m.from_user.id, "clock")
    tg.send_message(
        m.chat.id,
        f"Введи время напоминания (HH:MM).{extra}",
        reply_markup=types.ReplyKeyboardRemove(),
    )


@tg.message_handler(commands=["clear"])
def h_clear(m):
    if db.total(m.from_user.id) == 0:
        say(m.chat.id, "Нет записей для удаления.")
        return
    k = types.InlineKeyboardMarkup()
    k.row(
        types.InlineKeyboardButton("✅ Да, удалить всё", callback_data="cly"),
        types.InlineKeyboardButton("❌ Отмена", callback_data="cln"),
    )
    say(m.chat.id, "Удалить все записи?", k)


@tg.message_handler(func=lambda m: m.text in BTN.values())
def h_btn(m):
    uid, cid = m.from_user.id, m.chat.id
    if m.text == BTN["add"]:
        begin_add(cid, uid)
    elif m.text == BTN["stats"]:
        h_stats(m)
    elif m.text == BTN["hist"]:
        h_hist(m)
    else:
        h_set(m)


@tg.message_handler(func=lambda m: m.from_user.id in sess and step(m.from_user.id) in ("w+", "s+", "note", "clock"))
def h_type(m):
    uid, cid = m.from_user.id, m.chat.id
    st = step(uid)
    t = m.text.strip()

    if st == "w+":
        v = num_ok(t)
        if v is None:
            say(cid, "Введи число от 0 до 24.")
            return
        b = buf(uid)
        b["work"] = v
        go(uid, "sleep", b)
        say(cid, "Сколько часов спал?", sleep_btns())
        return

    if st == "s+":
        v = num_ok(t)
        if v is None:
            say(cid, "Введи число от 0 до 24.")
            return
        b = buf(uid)
        b["sleep"] = v
        go(uid, "note", b)
        k = types.InlineKeyboardMarkup()
        k.add(types.InlineKeyboardButton("Пропустить", callback_data="skip"))
        say(cid, "Комментарий? Напиши текст или нажми «Пропустить».", k)
        return

    if st == "note":
        finish(cid, uid, t)
        return

    if st == "clock":
        if not time_ok(t):
            say(cid, "Формат: HH:MM, например 09:00.")
            return
        db.set_alarm(uid, t)
        arm(uid, t)
        drop(uid)
        say(cid, f"Напоминание в {t}.")


@tg.callback_query_handler(func=lambda c: True)
def h_click(c):
    tg.answer_callback_query(c.id)
    uid, cid = c.from_user.id, c.message.chat.id
    code = c.data

    if code.startswith("m") and len(code) == 2 and step(uid) == "mood":
        b = buf(uid)
        b["mood"] = int(code[1])
        go(uid, "work", b)
        say(cid, "Сколько часов на работу/учёбу?", work_btns())
        return

    if code.startswith("w") and step(uid) == "work":
        b = buf(uid)
        if code == "w+":
            go(uid, "w+", b)
            say(cid, "Введи часы числом:")
            return
        b["work"] = float(code[1:])
        go(uid, "sleep", b)
        say(cid, "Сколько часов спал?", sleep_btns())
        return

    if code.startswith("s") and step(uid) == "sleep":
        b = buf(uid)
        if code == "s+":
            go(uid, "s+", b)
            say(cid, "Введи часы сна числом:")
            return
        b["sleep"] = float(code[1:])
        go(uid, "note", b)
        k = types.InlineKeyboardMarkup()
        k.add(types.InlineKeyboardButton("Пропустить", callback_data="skip"))
        say(cid, "Комментарий? Напиши текст или нажми «Пропустить».", k)
        return

    if code == "skip" and step(uid) == "note":
        finish(cid, uid, None)
        return

    if code == "st7":
        say(cid, analyzer.summary(db.days_list(uid, 7), "неделю"))
    elif code == "st30":
        say(cid, analyzer.summary(db.days_list(uid, 30), "месяц"))
    elif code == "stins":
        say(cid, analyzer.insights(db.days_list(uid, 30)))
    elif code == "stpic":
        pic = analyzer.chart(db.days_list(uid, 7))
        if pic:
            tg.send_photo(cid, pic, caption="График за 7 дней", reply_markup=menu())
        else:
            say(cid, "Нет данных для графика.")
    elif code == "cly":
        n = db.wipe(uid)
        say(cid, f"Удалено записей: {n}.")
    elif code == "cln":
        say(cid, "Отменено.")


def boot():
    db.setup()
    tg.set_my_commands(
        [
            types.BotCommand("start", "Приветствие и инструкция"),
            types.BotCommand("add", "Записать данные за сегодня"),
            types.BotCommand("stats", "Меню статистики"),
            types.BotCommand("history", "История записей"),
            types.BotCommand("settings", "Время напоминания"),
            types.BotCommand("clear", "Очистка данных"),
            types.BotCommand("help", "Справка"),
        ]
    )
    for u, t in db.all_alarms():
        if re.fullmatch(r"\d{2}:\d{2}", t):
            arm(u, t)


if __name__ == "__main__":
    boot()
    print("Бот запущен...")
    tg.infinity_polling()
